'use strict';

/**
 * @ngdoc function
 * @name dekaMirApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the dekaMirApp
 */
angular.module('dekaMirApp')
  .controller('AboutCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
