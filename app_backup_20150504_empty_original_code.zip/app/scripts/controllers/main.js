'use strict';

/**
 * @ngdoc function
 * @name dekaMirApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the dekaMirApp
 */
angular.module('dekaMirApp')
  .controller('MainCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
